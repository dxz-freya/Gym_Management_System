using GymManagement.Models;
using GymManagement.ViewModels;
namespace GymManagement.ViewModels
{
    public class BookingRequest
    {
        public int SessionId { get; set; }
    }
}
