using System.Collections.Generic;

namespace GymManagement.ViewModels.Payments
{
    public class PaymentsPageViewModel
    {
        public decimal WalletBalance { get; set; }
        public List<PaymentViewModel> Payments { get; set; } = new();
        public List<ChartBarViewModel> ChartData { get; set; } = new();
        public string? SelectedType { get; set; }
        public string? SelectedPeriod { get; set; }
    }
}
